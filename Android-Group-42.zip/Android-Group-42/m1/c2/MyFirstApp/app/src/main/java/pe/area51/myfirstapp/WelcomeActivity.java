package pe.area51.myfirstapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by alumno on 7/14/18.
 */

public class WelcomeActivity extends AppCompatActivity {

    public static final String EXTRA_NAME = "pe.area51.myfirstapp.Name";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        final TextView TextViewWelcomeMessage = findViewById(R.id.textViewWelcomeMessage);
        final Intent intentThatStartedThisActivity = getIntent();
        if(intentThatStartedThisActivity.hasExtra(EXTRA_NAME)){
            final TextView textViewWelcomeMessage = findViewById(R.id.textViewWelcomeMessage);
            final String name= intentThatStartedThisActivity.getStringExtra(EXTRA_NAME);
            final String welcomeText = getString(R.string.welcome,name);
            textViewWelcomeMessage.setText(welcomeText);
        }
    }
}

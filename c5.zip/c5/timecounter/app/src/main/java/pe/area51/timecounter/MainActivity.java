package pe.area51.timecounter;

import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private final static String SAVED_INSTANCE_KEY_IS_RUNNING = "is_running";
    private final static String SAVED_INSTANCE_KEY_START_TIME = "start_time";

    private TextView textViewTimeCount;
    //private int timeCount;
    private long startTime;
    private final static int DELAY_MS = 20;
    private boolean isRunning;

    private Handler handler;
    private Runnable runnableTimeCount;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewTimeCount = findViewById(R.id.textViewTimeCount);
        isRunning = false;

        handler = new Handler();
        runnableTimeCount = new Runnable() {
            @Override
            public void run() {
                //showTimeCount(timeCount);
                //timeCount++;
                final long elapsedTime = SystemClock.elapsedRealtime() - startTime;
                showTimeCount(elapsedTime);
                handler.postDelayed(this,DELAY_MS);
            }
        };

        if(savedInstanceState != null){
            isRunning = savedInstanceState.getBoolean(SAVED_INSTANCE_KEY_IS_RUNNING);
            startTime = savedInstanceState.getLong(SAVED_INSTANCE_KEY_START_TIME);

            if(isRunning){
                runnableTimeCount.run();
            }
        }else{
            isRunning = false;
        }


    }

   // @Override
    //protected void onRestoreInstanceState(Bundle savedInstanceState) {
      //  super.onRestoreInstanceState(savedInstanceState);
    //}

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(SAVED_INSTANCE_KEY_IS_RUNNING,isRunning);
        outState.putLong(SAVED_INSTANCE_KEY_START_TIME,startTime);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_schitch_timer:
                switchTimeCounter();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void switchTimeCounter(){

        if(isRunning){
            handler.removeCallbacks(runnableTimeCount);
            isRunning = false;
            return;
        }

        startTime = SystemClock.elapsedRealtime();
        //final Handler handler = new Handler();

        runnableTimeCount.run();
        isRunning = true;
    }

    private void showTimeCount(final long timeCount){
        textViewTimeCount.setText(String.valueOf(timeCount));
    }
}

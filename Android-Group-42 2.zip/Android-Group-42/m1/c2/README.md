MyFirstApp: Captura de eventos de los elementos del layout (View).
